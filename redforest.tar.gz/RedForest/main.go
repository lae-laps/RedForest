// main.go

/*

 +----------------------+
 |  RedForest toolkit   |
 | created by: lae-laps |
 +----------------------+

 */

package main

import (
)

func main() {
    DynamicInterface()
}

